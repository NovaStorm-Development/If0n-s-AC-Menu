﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Memory;

namespace trainerforassaultcube
{
    public partial class Form1 : Form
    {
        Mem meme = new Mem();

        string ammoAR = "ac_client.exe+0x0017E0A8,140";
        string ammoSniper = "ac_client.exe+0x0017E0A8,13C";
        string grenades = "ac_client.exe+0x0017E0A8,144";
        string health = "ac_client.exe+0x00109B74,F8";
        public Form1()
        {
            InitializeComponent();
        }
        Point lastPoint;

        private void Form1_Load(object sender, EventArgs e)
        {
            int PID = meme.GetProcIdFromName("ac_client");
            if (PID > 0)
            {
                meme.OpenProcess(PID);
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                meme.WriteMemory(ammoAR, "int", "999");
            }
            if (checkBox2.Checked == true)
            {
                meme.WriteMemory(grenades, "int", "999");
            }
            if (checkBox3.Checked == true)
            {
                meme.WriteMemory(ammoSniper, "int", "999");
            }
            if (checkBox4.Checked == true)
            {
                meme.WriteMemory(health, "int", "999");
            }

        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            string targetURL = @"https://discord.gg/wyM8TnxAh9";
            System.Diagnostics.Process.Start(targetURL);
        }
    }
}
